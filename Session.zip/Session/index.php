<?php
session_start();
include "connection.php";

if (isset($_POST['submit'])) {

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user_name = $_POST['user_name'];
        $password = $_POST['pass_word'];

        $sql = "SELECT pass_word, name FROM users WHERE BINARY user_name = '$user_name'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $stored_pass_word = $row['pass_word'];
            $name = $row['name'];

            if ($password === $stored_pass_word) {
                $_SESSION['user_name'] = $user_name;
                $_SESSION['name'] = $name;

                $_SESSION['LAST_ACTIVITY'] = time(); 

                if ($name === "Mayvelyn") {
                    header("Location: dashboard.php");
                    exit();
                }

            } else {
                $loginError = "Incorrect Username and Password";
            }

        } else {
            $loginError = "Incorrect Username and Password";
        }

    }
}

if (isset($_POST['logout'])) {
    session_start();
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

$conn->close();

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Session</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body class='d-flex align-items-center justify-content-center' style='height: 100vh;'>

  <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">

    <div class="container" style="max-width: 500px;">

      <div class="card p-4 shadow-lg rounded-5">

        <form action="" method="post">

          <div class="form-group">
            <h1 class="text-center">LOGIN</h1>
          </div>
          
          <div class="form-floating mb-3">
            <input type="text" class="form-control" id="floatingInput" name="user_name" placeholder="Username" required>
            <label for="floatingInput">Username</label>
          </div>

          <div class="form-floating mb-3">
            <input type="password" class="form-control" id="floatingPassword" name="pass_word" placeholder="Password" required>
            <label for="floatingPassword">Password</label>
          </div>
          
          <div class="d-flex justify-content-center">
            <button class="btn btn-primary" name="submit">Login</button>
          </div>

        </form>

      </div>

    </div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
  <?php if (!empty($loginError)): ?>
    Swal.fire({
      position: "center",
      icon: 'error',
      text: '<?php echo $loginError; ?>',
      showConfirmButton: false,
      timer: 1000
    });
  <?php endif; ?>
  </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>