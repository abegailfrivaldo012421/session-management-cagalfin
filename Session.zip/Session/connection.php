<?php

    $servername = "localhost";
    $user_name = "root";
    $pass_word = "";
    $dbname = "session";

    try {
        $conn = new mysqli($servername, $user_name, $pass_word, $dbname);

        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        
    } catch (Exception $e) {
        
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
        echo "<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>";
        echo "<title>System Down</title>";
        echo "</head>";
        echo "<body class='d-flex align-items-center justify-content-center' style='height: 100vh;'>";
        echo "<div class='text-center'>";
        echo "<h1 class='ri-error-warning-line text-danger' style='font-size: 250px;'></h1>";
        echo "<h1>System is Down</h1>";
        echo "<p>Contact developer</p>";
        echo "</div>";
        echo "</body>";
        echo "</html>";
        exit();

    }

?>